const socket = io();
let cn_e;
socket.on('mesaj', (mesaj,nume,catiis)=>{
    console.log(mesaj,nume,"sunt "+catiis);
    if(catiis>2)
    window.location="/neparerau.html";
    let who= document.querySelector('#cne');
    who.innerHTML=nume;    
    cn_e=catiis;
    cinee();    
});
var b1,b2,b3,b4,b5,b6;
let who= document.querySelector('#cne');
var WHITECOLOR, BLACKCOLOR;
b1=document.querySelector('#u1');
b2=document.querySelector('#u2');
b3=document.querySelector('#u3');
b4=document.querySelector('#u4');
b5=document.querySelector('#u5');
b6=document.querySelector('#u6');

let cl1="#ffffff";
let cl2="#000000";
let cl3="#5926d1";
let cl4="#09ed3b";
let cl5="#e8000c";
let cl6="#e6c32c";
b1.colour = cl1;
b2.colour = cl2;
b3.colour = cl3;
b4.colour = cl4;
b5.colour = cl5;
b6.colour = cl6;

//
// window.addEventListener('load', (event) => {
//   who.innerHTML="Jucătoru #1";
// });
function click2(evt)
{
var clr = evt.currentTarget.colour;
socket.emit('culoarea', clr, cn_e);
console.log('culoarea ', clr, cn_e);
var piese=document.querySelectorAll('.black');
for(var i=0;i<piese.length;i++)
  {
    piese[i].style.backgroundColor=clr;
  }
  b1.removeEventListener('click',click2);
  b2.removeEventListener('click',click2);
  b3.removeEventListener('click',click2);
  b4.removeEventListener('click',click2);
  b5.removeEventListener('click',click2);
  b6.removeEventListener('click',click2);
  BLACKCOLOR = clr;
  var barnea = document.querySelector('.hower');
  barnea.innerHTML = "";
  $(".hower2").show();
//  socket.emit('culoare',1, BLACKCOLOR);
}
function click1(evt){
  var clr=evt.currentTarget.colour;
  socket.emit('culoarea', clr, cn_e);
  console.log('culoarea ', clr, cn_e);
  var piese=document.querySelectorAll('.white');
  for(var i=0;i<piese.length;i++)
    {
      piese[i].style.backgroundColor=clr;
    }
    var barnea = document.querySelector('.hower');
    barnea.innerHTML = "";
    evt.currentTarget.outerHTML=evt.currentTarget.outerHTML;
    socket.emit('culoare',0, WHITECOLOR);
 b1.removeEventListener('click',click1);
 b2.removeEventListener('click',click1);
 b3.removeEventListener('click',click1);
 b4.removeEventListener('click',click1);
 b5.removeEventListener('click',click1);
 b6.removeEventListener('click',click1);
 $(".hower2").show();
}

function cinee(q){
if(cn_e==1){
b1.addEventListener('click',click1);
b2.addEventListener('click',click1);
b3.addEventListener('click',click1);
b4.addEventListener('click',click1);
b5.addEventListener('click',click1);
b6.addEventListener('click',click1);
}
else{
  b1.addEventListener('click',click2);
  b2.addEventListener('click',click2);
  b3.addEventListener('click',click2);
  b4.addEventListener('click',click2);
  b5.addEventListener('click',click2);
  b6.addEventListener('click',click2);
}
}

socket.on('START',(c1,c2)=>{
  asc(1);
  WHITECOLOR=c1;
  BLACKCOLOR=c2;
  startPieces();
});

socket.on('STOP', ()=>{
  window.location="/neparerau2.html";
});


function roll() // dai cu zarul
{
    //if(canbepressed)
   // {
        die3 = 0;
    die1 = Math.ceil(Math.random()*6) ;
    die2 = Math.ceil(Math.random()*6) ;
    die1 > 0 ? 0 : die1++;
    die2 > 0 ? 0 : die2++;
    if(die1 > die2)
    [die1,die2] = [die2,die1];
    zaruri(die1,die2);
    socket.emit('zaruri', die1, die2);
    if(die1 == die2)
    {die1 *= 4;
        die2 = 0;
        die3 = die1/4;
    }
   // socket.emit('zaruri', )
  //}
}

buton.addEventListener('click',roll);
buton.addEventListener('click',start);

socket.on('zaruri', (z1,z2)=>{
  zaruri(z1,z2);
})